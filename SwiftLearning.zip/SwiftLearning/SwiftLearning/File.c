//
//  File.c
//  SwiftLearning
//
//  Created by Hunk on 14-6-16.
//  Copyright (c) 2014年 dianxinOS. All rights reserved.
//

#include <stdio.h>

void test() {
    printf("This is a function call from C.");
}